Escribe un programa que imprima el texto "HELLO WORLD" en consola (stdout).

----------------------------------------------------------------------
## PISTAS

Para escribir un programa en Node.js, crea un archivo con extensión `.js` y dentro escribe JavaScript! Para ejecutarlo usa el comando 'node', por ejemplo:
```sh
$ node program.js
```

Puedes escribir a consola de la misma forma que en el navegador(browser):

```js
console.log("texto")
```

Cuando termines debes ejecutar:

```sh
$ {appname} verify program.js
```

para continuar con el siguiente ejercicio. Tu programa será probado, se generará un reporte y si todo funciona correctamente se etiquetará el ejercicio como 'completado'.

----------------------------------------------------------------------
