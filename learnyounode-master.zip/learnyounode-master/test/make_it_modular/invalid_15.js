var mymodule = require('./module_invalid_15.js');

mymodule();