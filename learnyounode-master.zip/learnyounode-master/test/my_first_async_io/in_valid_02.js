var fs = require('fs')
  , path = require('path')

fs.readFile(process.argv[2]), count_new_lines)

function count_new_lines(error, text) {
	console.log(-1)
}